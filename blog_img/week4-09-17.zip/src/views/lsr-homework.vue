<template>
    <div :class="myclass">
        <span>用户名：</span><input type="text" v-model="usename"><span>{{username}}</span>
        <span>密码：</span><input type="password" :value="password"><span>{{password}}</span>
    </div>
</template>

<style>
.lsrclass{
    background:pink;
    margin: 0% auto;
    width: 50%;
    display: flex;
    justify-content: space-around;
}
</style>

<script>
export default {
    data() {
        return {
            myclass: 'lsrclass',
            username:'请输入用户名',
            password:'请输入密码'
        };
    },
}
</script>
